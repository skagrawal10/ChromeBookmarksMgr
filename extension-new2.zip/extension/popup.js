chrome.tabs.onUpdated.addListener( function (tabId, changeInfo, tab) {
  if (changeInfo.status == 'complete' && tab.active) {
	//chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
	url = tab.url;
	if(url.indexOf("chrome://") != -1 || url.indexOf("safe-caverns-4059.herokuapp.com") != -1 || url.indexOf("https://mail.google.com") != -1)
		return;
    chrome.tabs.sendMessage(tab.id, {method: "getText"}, function(response) {
        if(response.method=="getText"){
            alltext = response.data;
			saveIntoServer(alltext, tab.url);
        }
		});
	

  }
});
/*
$(document).ready(function()
{
	body = document.body;
	content = body.textContent;
	saveIntoServer();
})
;
*/
function saveIntoServer(content, url)
{
	$.ajax({
		type: "POST",
		url: "https://safe-caverns-4059.herokuapp.com/vrp/saveWebContent",
		data: {"data" : content, "url" : url},
		success: function(msg){
			
	   },
	   error: function(){
			alert("Error occured during data send");
			}
	   });
}
